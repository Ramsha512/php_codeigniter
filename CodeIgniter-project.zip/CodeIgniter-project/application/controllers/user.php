<?php

class user extends My_Controller{
    public function index()
    {

       $this->load->view('users/articleList');
    }
}

?>