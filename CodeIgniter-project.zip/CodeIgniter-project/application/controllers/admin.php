<?php
class admin extends My_Controller{
    public function index()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('username','Username','required|alpha|max_length[30]');
        $this->form_validation->set_rules('password','Password','required|max_length[12]');
        
        $this->form_validation->set_error_delimiters("<div style='color:red;'>","</div>");
        if($this->form_validation->run())
        {
        echo"validation successful";
        }
        else
        {
            $this->load->view('users/articleList');
          }

    }
}


?>